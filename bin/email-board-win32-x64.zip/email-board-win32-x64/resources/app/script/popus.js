"use strict";
const $ = require('jquery');
$('');
