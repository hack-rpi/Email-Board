/// <reference path="../../typings/index.d.ts" />
"use strict";
require('./script/db-dialog');
require('./script/email');
require('./script/mailgun-dialog');
require('./script/menu');
require('./script/mongo');
require('./script/query-dialog');
const main = require('./script/main');
const $ = require('jquery');
$(document).ready(main.load);
