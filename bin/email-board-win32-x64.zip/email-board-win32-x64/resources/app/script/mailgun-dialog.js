/// <reference path="../../typings/index.d.ts" />
/// <reference path="../../definitions/index.d.ts" />
"use strict";
const $ = require('jquery');
const storage = require('electron-json-storage');
const popup_1 = require('./popup');
exports.api_key = '';
exports.domain = '';
storage.get('mailgun', function (error, data) {
    if (error) {
        console.error(error);
    }
    else {
        exports.api_key = data.api_key;
        exports.domain = data.domain;
    }
});
$('body').on('click', '#mailgun-dialog .button#save', function (event) {
    exports.api_key = $('#mailgun-dialog input[name="API Key"]').val();
    exports.domain = $('#mailgun-dialog input[name="Domain"]').val();
    storage.set('mailgun', { api_key: exports.api_key, domain: exports.domain }, function (error) {
        if (error) {
            console.error(error);
        }
    });
    popup_1.close();
});
