/// <reference path="../../typings/index.d.ts" />
"use strict";
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
let curr_uri = undefined;
const mongo_uri_re = new RegExp('mongodb://.+');
/**
 *
 */
function connect(uri, cb) {
    if (!mongo_uri_re.test(uri)) {
        return cb(false);
    }
    ;
    MongoClient.connect(uri, function (error, db) {
        if (error) {
            console.error(error);
            return cb(false);
        }
        else {
            curr_uri = uri;
            db.close();
            return cb(true);
        }
    });
}
exports.connect = connect;
/**
 *
 */
function count(collection, query, cb) {
    if (!curr_uri) {
        console.error('Not connected to database.');
        return cb(true, null);
    }
    MongoClient.connect(curr_uri, function (error, db) {
        if (error) {
            console.error(error);
            db.close();
            return cb(true, null);
        }
        else {
            db.collection(collection).count(query).then((count) => {
                db.close();
                return cb(false, count);
            }).catch((reason) => {
                console.error(reason);
                db.close();
                return cb(true, null);
            });
        }
    });
}
exports.count = count;
/**
 *
 */
function find(collection, query, cb) {
    if (!curr_uri) {
        console.error('Not connected to database.');
        return cb(true, null);
    }
    MongoClient.connect(curr_uri, function (error, db) {
        if (error) {
            console.error(error);
            db.close();
            return cb(true, null);
        }
        else {
            db.collection(collection).find(query).toArray().then((data) => {
                db.close();
                return cb(false, data);
            }).catch((reason) => {
                console.error(reason);
                db.close();
                return cb(true, null);
            });
        }
    });
}
exports.find = find;
