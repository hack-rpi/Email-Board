/// <reference path="../../typings/index.d.ts" />
"use strict";
const fs = require('fs');
const $ = require('jquery');
const Mustache = require('mustache');
let in_focus = undefined;
function open(name, id, data) {
    if (id === in_focus)
        return;
    $('#' + id).remove();
    fs.readFile(__dirname + '/../templates/' + name, 'utf-8', (error, template) => {
        if (error) {
            console.error(error);
        }
        else {
            let rendered = Mustache.render(template, { data: data });
            $('body').append(rendered);
            in_focus = id;
        }
    });
}
exports.open = open;
function close() {
    $('#' + in_focus).remove();
    in_focus = undefined;
}
exports.close = close;
$('body').on('click', '.close', close);
$('body').on('click', '.overlay', close);
$('body').on('click', '.popup', function (event) {
    event.stopPropagation();
});
