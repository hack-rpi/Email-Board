/// <reference path="../../typings/index.d.ts" />
"use strict";
const fs = require('fs');
const Mustache = require('mustache');
const storage = require('electron-json-storage');
function load() {
    fs.readFile(__dirname + '/../templates/index.mst', 'utf-8', (error, template) => {
        if (error) {
            console.error(error);
        }
        else {
            storage.get('templates', function (error, templates) {
                if (error) {
                    console.error(error);
                }
                else {
                    let rendered = Mustache.render(template, { templates: templates });
                    $('.content').html(rendered);
                }
            });
        }
    });
}
exports.load = load;
