/// <reference path="../../typings/index.d.ts" />
/// <reference path="../../definitions/index.d.ts" />
"use strict";
const fs = require('fs');
const Mustache = require('mustache');
const $ = require('jquery');
const { dialog } = require('electron').remote;
$('body').on('click', '.button#load-template', function (event) {
    dialog.showOpenDialog({
        title: 'Open New Email Template',
        filters: [
            { name: 'Templates', extensions: ['html'] },
            { name: 'All Files', extensions: ['*'] }
        ]
    }, function (fileNames) {
        if (fileNames.length >= 0) {
            openTemplate(fileNames[0]);
        }
    });
});
function openTemplate(filename) {
    fs.readFile(filename, 'utf-8', (error, template) => {
        if (error) {
            console.error(error);
        }
        else {
            let renderedEmail = Mustache.render(template, {});
            fs.readFile(__dirname + '/../templates/email.mst', 'utf-8', (error, template) => {
                if (error) {
                    console.error(error);
                }
                else {
                    let rendered = Mustache.render(template, { email: renderedEmail });
                    $('.content').html(rendered);
                }
            });
        }
    });
}
